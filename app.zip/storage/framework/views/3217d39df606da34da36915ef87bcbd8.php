
<?php $__env->startSection('main'); ?>
    <div class="container-xxl py-5 bg-primary hero-header mb-5">
        <div class="container my-5 py-5 px-lg-5">
            <div class="row g-5 py-5">
                <div class="col-12 text-center">
                    <h1 class="text-white animated zoomIn">Haqqımızda</h1>
                    <hr class="bg-white mx-auto mt-0" style="width: 90px;">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="/">Ana Səhifə</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Haqqımızda</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- Navbar & Hero End -->



    <!-- About Start -->
    <div class="container-xxl py-5">
        <div class="container px-lg-5">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="section-title position-relative mb-4 pb-2">
                        <h6 class="position-relative text-primary ps-4">Haqqımızda</h6>
                        <h2 class="mt-2"><?php echo e($about->title); ?></h2>
                    </div>
                    <p class="mb-4"><?php echo e($about->content_short); ?></p>
                    <div class="row g-3">
                        <?php $__currentLoopData = $about->getItemsGroup(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-6">
                                <?php $__currentLoopData = $itemGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h6 class="mb-3"><i class="fa fa-check text-primary me-2"></i><?php echo e($item); ?></h6>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="d-flex align-items-center mt-4">
                        <?php if($setting->facebook): ?>
                            <a class="btn btn-outline-primary btn-square me-3" target="_blank"
                                href="<?php echo $setting->facebook; ?>"><i class="fab fa-facebook-f"></i></a>
                        <?php endif; ?>
                        <?php if($setting->twitter): ?>
                            <a class="btn btn-outline-primary btn-square me-3" target="_blank"
                                href="<?php echo $setting->twitter; ?>"><i class="fab fa-twitter"></i></a>
                        <?php endif; ?>
                        <?php if($setting->instagram): ?>
                            <a class="btn btn-outline-primary btn-square me-3" target="_blank"
                                href="<?php echo $setting->instagram; ?>"><i class="fab fa-instagram"></i></a>
                        <?php endif; ?>
                        <?php if($setting->youtube): ?>
                            <a class="btn btn-outline-primary btn-square me-3" target="_blank"
                                href="<?php echo $setting->youtube; ?>"><i class="fab fa-youtube"></i></a>
                        <?php endif; ?>
                        <?php if($setting->whatsapp): ?>
                            <a class="btn btn-outline-primary btn-square me-3" target="_blank"
                                href="<?php echo $setting->whatsapp; ?>"><i class="fab fa-whatsapp"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6">
                    <img class="img-fluid wow zoomIn" data-wow-delay="0.5s" src="/storage/<?php echo e($about->image_url); ?>">
                </div>
            </div>
            <div class="row g-5">
                <div class="col-lg-6">
                    <img class="img-fluid wow zoomIn" data-wow-delay="0.5s" src="/front/img/about-2.webp">
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <p class="mb-4"><?php echo $about->content; ?></p>
                </div>

            </div>
        </div>
    </div>
    <!-- About End -->


    <!-- Newsletter Start -->
    <div class="container-xxl bg-primary newsletter my-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container px-lg-5">
            <div class="row align-items-center" style="height: 250px;">
                <div class="col-12 col-md-6">
                    <h3 class="text-white">Başlamağa hazırsınız?</h3>
                    <small class="text-white">Sizə daha yaxşı xidmət göstərmək üçün əlaqə nömrənizi daxil edin.</small>
                    <?php if(Session::has('success')): ?>
                        <div class="col-md-12 mb-2">
                            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('warning')): ?>
                        <div class="col-md-12 mb-2">
                            <div class="alert alert-danger"><?php echo e(Session::get('warning')); ?></div>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('application-short.post')); ?>" method="POST"
                        class="position-relative w-100 mt-3">
                        <?php echo csrf_field(); ?>
                        <input class="form-control border-0 rounded-pill w-100 ps-4 pe-5" type="text"
                            placeholder="Əlaqə nömrənizi daxil edin" name="phone_number" style="height: 48px;">
                        <button type="submit" class="btn shadow-none position-absolute top-0 end-0 mt-1 me-2"><i
                                class="fa fa-paper-plane text-primary fs-4"></i></button>
                    </form>
                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 text-center mb-n5 d-none d-md-block">
                    <img class="img-fluid mt-5" style="height: 250px;" src="/front/img/newsletter.png">
                </div>
            </div>
        </div>
    </div>
    <!-- Newsletter End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wampServer\www\MyLaravelProject\MasterSayt\resources\views/front/about.blade.php ENDPATH**/ ?>