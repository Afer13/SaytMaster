
<?php $__env->startSection('main'); ?>
    <div class="container-xxl py-5 bg-primary hero-header mb-5">
        <div class="container my-5 py-5 px-lg-5">
            <div class="row g-5 py-5">
                <div class="col-lg-6 text-center text-lg-start">
                    <h1 class="text-white mb-4 animated zoomIn">Veb Sayt Hazırlama Xidmətləri ilə İşinizi Sürətlə
                        Genişləndirin</h1>
                    <p class="text-white pb-3 animated zoomIn">Bizim peşəkar komandamız sizin üçün yüksək keyfiyyətli və
                        funksional veb saytlar hazırlayır. Müasir texnologiyalar və kreativ dizaynlarla işinizin rəqəmsal
                        dünyada uğur qazanmasını təmin edirik. Keyfiyyətli və effektiv həllər üçün bizə müraciət edin.</p>
                    <a href="" class="btn btn-light py-sm-3 px-sm-5 rounded-pill me-3 animated slideInLeft">Layihəniz
                        var?</a>
                    <a href=""
                        class="btn btn-outline-light py-sm-3 px-sm-5 rounded-pill animated slideInRight">İşlərimiz</a>
                </div>
                <div class="col-lg-6 text-center text-lg-start">
                    <img class="img-fluid" src="/front/img/hero-2.png" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- About Start -->
    <div class="container-xxl py-5">
        <div class="container px-lg-5">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="section-title position-relative mb-4 pb-2">
                        <h6 class="position-relative text-primary ps-4">Haqqımızda</h6>
                        <h2 class="mt-2"><?php echo e($about->title); ?></h2>
                    </div>
                    <p class="mb-4"><?php echo e($about->content_short); ?></p>
                    <div class="row g-3">
                        <?php $__currentLoopData = $about->getItemsGroup(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-6">
                                <?php $__currentLoopData = $itemGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h6 class="mb-3"><i class="fa fa-check text-primary me-2"></i><?php echo e($item); ?></h6>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <div class="d-flex align-items-center mt-4">
                        <a class="btn btn-primary rounded-pill px-4 me-3" href="/about-us">Daha Ətraflı</a>
                        <?php if($setting->facebook): ?>
                            <a class="btn btn-outline-primary btn-square me-3" target="_blank"
                                href="<?php echo $setting->facebook; ?>"><i class="fab fa-facebook-f"></i></a>
                        <?php endif; ?>
                        <?php if($setting->twitter): ?>
                            <a class="btn btn-outline-primary btn-square me-3" target="_blank"
                                href="<?php echo $setting->twitter; ?>"><i class="fab fa-twitter"></i></a>
                        <?php endif; ?>
                        <?php if($setting->instagram): ?>
                            <a class="btn btn-outline-primary btn-square me-3" target="_blank"
                                href="<?php echo $setting->instagram; ?>"><i class="fab fa-instagram"></i></a>
                        <?php endif; ?>
                        <?php if($setting->youtube): ?>
                            <a class="btn btn-outline-primary btn-square me-3" target="_blank"
                                href="<?php echo $setting->youtube; ?>"><i class="fab fa-youtube"></i></a>
                        <?php endif; ?>
                        <?php if($setting->whatsapp): ?>
                            <a class="btn btn-outline-primary btn-square me-3" target="_blank"
                                href="<?php echo $setting->whatsapp; ?>"><i class="fab fa-whatsapp"></i></a>
                        <?php endif; ?>

                    </div>
                </div>
                <div class="col-lg-6">
                    <img class="img-fluid wow zoomIn" data-wow-delay="0.5s" src="/storage/<?php echo e($about->image_url); ?>">
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->


    <!-- Newsletter Start -->
    <div class="container-xxl bg-primary newsletter my-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container px-lg-5">
            <div class="row align-items-center" style="height: 250px;">
                <div class="col-12 col-md-6">
                    <h3 class="text-white">Başlamağa hazırsınız?</h3>
                    <small class="text-white">Sizə daha yaxşı xidmət göstərmək üçün əlaqə nömrənizi daxil edin.</small>
                    <?php if(Session::has('success')): ?>
                        <div class="col-md-12 mb-2">
                            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('warning')): ?>
                        <div class="col-md-12 mb-2">
                            <div class="alert alert-danger"><?php echo e(Session::get('warning')); ?></div>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('application-short.post')); ?>" method="POST"
                        class="position-relative w-100 mt-3">
                        <?php echo csrf_field(); ?>
                        <input class="form-control border-0 rounded-pill w-100 ps-4 pe-5" type="text"
                            placeholder="Əlaqə nömrənizi daxil edin" name="phone_number" style="height: 48px;">
                        <button type="submit" class="btn shadow-none position-absolute top-0 end-0 mt-1 me-2"><i
                                class="fa fa-paper-plane text-primary fs-4"></i></button>
                    </form>
                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 text-center mb-n5 d-none d-md-block">
                    <img class="img-fluid mt-5" style="height: 250px;" src="/front/img/newsletter.png">
                </div>
            </div>
        </div>
    </div>
    <!-- Newsletter End -->


    <!-- Service Start -->
    <div class="container-xxl py-5">
        <div class="container px-lg-5">
            <div class="section-title position-relative text-center mb-5 pb-2 wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="position-relative d-inline text-primary ps-4">Bizim xidmətlərimiz</h6>
                <h2 class="mt-2">Hansı Həlləri Təqdim Edirik</h2>
            </div>
            <div class="row g-4">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.1s">
                        <div class="service-item d-flex flex-column justify-content-center text-center rounded">
                            <div class="service-icon flex-shrink-0">
                                <i class="<?php echo $service->icon; ?> fa-2x"></i>
                            </div>
                            <h5 class="mb-3"><?php echo $service->title; ?></h5>
                            <p><?php echo $service->content_short; ?></p>
                            <a class="btn px-3 mt-auto mx-auto" href="/services/<?php echo $service->slug; ?>">Daha Ətraflı</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- Service End -->


    <!-- Portfolio Start -->
    <div class="container-xxl py-5">
        <div class="container px-lg-5">
            <div class="section-title position-relative text-center mb-5 pb-2 wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="position-relative d-inline text-primary ps-4">İşlərimiz</h6>
                <h2 class="mt-2">Gördüyümüz işlər</h2>
            </div>
            
            <div class="row g-4 portfolio-container">
                <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 portfolio-item first wow zoomIn" data-wow-delay="0.1s">
                        <div class="position-relative rounded overflow-hidden">
                            <img class="img-fluid w-100" src="/storage/<?php echo e($portfolio->image_url); ?>"
                                alt="<?php echo e($portfolio->title); ?>">
                            <div class="portfolio-overlay">
                                
                                <div class="mt-auto">
                                    
                                    <a class="h5 d-block text-white mt-1 mb-0" href=""><?php echo e($portfolio->title); ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
    <!-- Portfolio End -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wampServer\www\MyLaravelProject\MasterSayt\resources\views/front/index.blade.php ENDPATH**/ ?>