
<?php $__env->startSection('main'); ?>
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>About Us</h1>
        </div>

        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <form class="row g-3" action="<?php echo e(route('admin.about.update')); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="col-12">
                                    <label for="inputTitle" class="form-label">Title</label>
                                    <input type="text" value="<?php echo e(optional($about)->title ?? ''); ?>" class="form-control"
                                        name="title" id="inputTitle">
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-12">
                                    <label for="inputContentShort" class="form-label">Content Short</label>
                                    <textarea cols="30" rows="3" class="form-control" name="content_short" id="inputContentShort"><?php echo e(optional($about)->content_short ?? ''); ?></textarea>
                                    <?php $__errorArgs = ['content_short'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-12">
                                    <label for="inputContent" class="form-label">Content</label>
                                    <textarea class="tinymce-editor" name="content" id="inputContent"><?php echo e(optional($about)->content ?? ''); ?></textarea>
                                    <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div>
                                    <label class="form-label">Items</label>
                                    <div class="row items-box">
                                        <?php if($about && $about->getItems()): ?>
                                            <?php $__currentLoopData = $about->getItems(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-6 mt-1" id="item-<?php echo e($key); ?>">
                                                    <div class="input-group" >
                                                        <input type="text" name="items[]" placeholder="Item" value="<?php echo e($item); ?>"
                                                            class="form-control">
                                                        <span class="input-group-text"><i class="bi bi-trash delete-item"
                                                                data-id="<?php echo e($key); ?>"></i></span>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <div class="col-6 mt-1" id="item-0">
                                                <div class="input-group" >
                                                    <input type="text" name="items[]" placeholder="Item" class="form-control">
                                                    <span class="input-group-text"><i class="bi bi-trash delete-item"
                                                            data-id="0"></i></span>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="text-center mt-2">
                                        <button type="button" class="btn btn-primary add-item w-50"><i
                                                class="bi bi-plus"></i></button>
                                    </div>
                                    <?php $__errorArgs = ['items'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-12">
                                    <label for="inputLogo" class="form-label">Image</label>
                                    <div>
                                        <?php if($about): ?>
                                            <img class="col-2 m-1" src="/storage/<?php echo e($about->image_url); ?>" alt="Image">
                                        <?php else: ?>
                                            No Image
                                        <?php endif; ?>
                                    </div>
                                    <input type="file" class="form-control" name="image" id="inputImage">
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            function getRandom() {
                return (Math.random() + 1).toString(36).substring(7);
            }
            $('.add-item').click(function() {
                let id = getRandom();
                var html = `<div class="col-6 mt-1" id="item-${id}"><div class="input-group" >
                            <input type="text" name="items[]" placeholder="Item" class="form-control">
                            <span class="input-group-text"><i class="bi bi-trash delete-item" data-id="${id}"></i></span>
                        </div></div>`;
                $('.items-box').append(html);
            });
            $('html').on('click','.delete-item',function() {
                var id=$(this).data('id');
                $('#item-'+id).remove();
            });
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wampServer\www\MyLaravelProject\MasterSayt\resources\views/admin/about/index.blade.php ENDPATH**/ ?>